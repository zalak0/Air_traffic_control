#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>
#include "message.h" // Include the message.h header file

#define BUFFER_SIZE 256

char *last_five_chars(char *str) {
    int len = strlen(str);
    // Return the last 5 characters or the whole string if it's shorter.
    return (len >= 5) ? &str[len - 5] : str;
}

double min(double x, double y) {
  return (x < y) ? x : y;
}

double distance(double x, double y){
    double distance = sqrt(pow(x,2) + pow(y,2));
    return distance;
}

typedef struct {
    ADSBPacket *plane_data;
    int n;         // current size of array
    int capacity;  // how much memory has and could be allocated to data
} List;

List init_list(void) {
    List list;
    list.n = 0;
    list.capacity = 10; // Initial capacity
    list.plane_data = malloc(list.capacity * sizeof(ADSBPacket));
    return list;
}

int find_aircraft_index(List *list, int aircraft_id, int aircraft_index){
    // Check for duplicates by searching the list for the same ID
    for (int i = 0; i < list->n; i++) {
        if (list->plane_data[i].id == aircraft_id) {
            aircraft_index = i;
            break; // Found a matching ID, exit the loop
        }
    }
    return aircraft_index;
}

void append_data(List *list, ADSBPacket data_in) {
    int aircraft_index = -1; //used to find aircraft id inputted
    aircraft_index = find_aircraft_index(list, data_in.id, aircraft_index);

   if (aircraft_index != -1) {
        // Update the existing data
        list->plane_data[aircraft_index] = data_in;
    }
    else {
        // No duplicate found, add the new data
        if (list->n >= list->capacity) {
            // Check if the current index exceeds the capacity
            list->capacity *= 2;
            list->plane_data = realloc(list->plane_data, list->capacity * sizeof(ADSBPacket));
        }
        list->plane_data[list->n] = data_in;
        list->n++;
    }
}

double *est_position(List *list, int aircraft_id, char command[BUFFER_SIZE], double store_est_val[BUFFER_SIZE]) {
    char hour[BUFFER_SIZE];
    char minute[BUFFER_SIZE];

    // input command time extraction
    strncpy(hour, command + 6, 2);
    strncpy(minute, command + 9, 2);

    int aircraft_index = -1; //used to find aircraft id inputted
    aircraft_index = find_aircraft_index(list, aircraft_id, aircraft_index);

    //conversion to use in calculations
    int est_hour = atoi(hour);
    int est_minute = atoi(minute);

    //if the aircraft was found
    if (aircraft_index != -1) {
        // convert from km/h to km/s
        double speed = list->plane_data[aircraft_index].speed;
        //converting heading to radian form
        double heading_rad = list->plane_data[aircraft_index].heading * M_PI / 180.0;

        store_est_val[2] = speed * sin(heading_rad) / 1000.0; //v_north
        store_est_val[3] = speed * cos(heading_rad) / 1000.0; //v_east

        // time offset based on formula given in overview
        double est_offset = (est_hour - list->plane_data[aircraft_index].hour) * 3600.0 +
                            (est_minute - list->plane_data[aircraft_index].minute) * 60.0;


        store_est_val[0] = list->plane_data[aircraft_index].north + store_est_val[2] * est_offset; //est_north
        store_est_val[1] = list->plane_data[aircraft_index].east + store_est_val[3] * est_offset; //est_east

        double aircraft_index = aircraft_index; //convert from integer to double to store in array
        store_est_val[4] = aircraft_index;

        return store_est_val;
    } 
    else if ((aircraft_index = -1)){
        // Aircraft with the specified ID was not found
        /*Initialising array, store_est_val[4] represents aircraft_index, so it must be -1
        to print "Aircraft currently not in area of operation" (see input command). 
        Other array values can be initialised to any other values*/
        store_est_val[0] = -1.0; 
        store_est_val[1] = -1.0;
        store_est_val[2] = -1.0;
        store_est_val[3] = -1.0;
        store_est_val[4] = -1;
        return store_est_val;
    }
}

double *check_separation(List *list, int aircraft_id, char command[BUFFER_SIZE], double R, double pos[3]) {
    double **stored_est_val = (double **)malloc(list->n * sizeof(double *));
    
    double oldt; //stores old 'min_intersect_t' variable for comparison to find most 'dangerous' separation issue
    int safe_altitude = 750;
    int aircraft_index = -1; //used to find aircraft id inputted 
    aircraft_index = find_aircraft_index(list, aircraft_id, aircraft_index);

    for (int i = 0; i < list->n; i++) {
        stored_est_val[i] = (double *)malloc(BUFFER_SIZE * sizeof(double));
        est_position(list, list->plane_data[i].id, command, stored_est_val[i]);
    }

    for (int i = 0; i < list->n; i++) {
        if (i != aircraft_index) {  
            double sum_pos_north = stored_est_val[aircraft_index][0] - stored_est_val[i][0];
            double sum_pos_east = stored_est_val[aircraft_index][1] - stored_est_val[i][1];
            double sum_v_north = stored_est_val[aircraft_index][2] - stored_est_val[i][2];
            double sum_v_east = stored_est_val[aircraft_index][3] - stored_est_val[i][3];
            double sum_altitude = list->plane_data[aircraft_index].altitude - list->plane_data[i].altitude;
        
            if (fabs(sum_altitude) > safe_altitude){
                break; //will print "no separation issues" out of the loop 
            }
            // Applying formulae given in the overview and setting up discriminant calculation
            double a = pow(distance(sum_v_north, sum_v_east),2);
            double b = 2 * (sum_v_north * sum_pos_north + sum_v_east * sum_pos_east);
            double c = pow(distance(sum_pos_north, sum_pos_east),2) - pow(R, 2);
            double d = pow(b, 2) - 4 * a * c; // Discriminant
            if (d >= 0) {
                double sum_intersect_t1 = (-b + sqrt(d)) / (2 * a);
                double sum_intersect_t2 = (-b - sqrt(d)) / (2 * a);
                double min_intersect_t = min(sum_intersect_t1, sum_intersect_t2); // Choose the smallest non-negative root
                if (min_intersect_t >= 0) {
                    if (!pos[2] || oldt > min_intersect_t) {
                        //applying formulae from overview
                        pos[0] = stored_est_val[aircraft_index][0] + stored_est_val[aircraft_index][2] * min_intersect_t;
                        pos[1] = stored_est_val[aircraft_index][1] + stored_est_val[aircraft_index][3] * min_intersect_t;
                        pos[2] = 1; // Set the flag to indicate a separation issue
                        oldt = min_intersect_t; 
                        //minimum is set, we want the lowest number to be oldt for later comparison
                    }
                }
            }
        }
    }
    // Free dynamically allocated memory
    for (int i = 0; i < list->n; i++) {
        free(stored_est_val[i]);
    }
    free(stored_est_val);
    return pos;
}

void print_est_position(List *list, char command[BUFFER_SIZE]){
    //Defining variables
    int operating_radius = 350;
    char est_id[BUFFER_SIZE];
    strcpy(est_id, command + 20); //collecting the ID number we are estimating the position for
    int est_id_plane = atoi(est_id); 
    //Defining array to store values within functions to return
    double store_est_vals[BUFFER_SIZE];
    //Running calculations
    double *stored_est_val = est_position(list, est_id_plane, command, store_est_vals); //5 return values, refer to first array

    if ((distance(stored_est_val[0], stored_est_val[1]) >= operating_radius) || (stored_est_val[4] == -1.0)){ 
        printf("Aircraft (ID:%d) not currently in area of operation\n", est_id_plane);
    }
    else{
        printf("Aircraft (ID:%d): Estimated Position: N:%.1lf,E:%.1lf\n", est_id_plane, stored_est_val[0], stored_est_val[1]);
    }
}

void print_num_contacts(List *list, char command[BUFFER_SIZE]) {
    //Defining variables
    int plane_counter = 0;
    int operating_radius = 350;
    for (int i = 0; i < list->n; i++) {
        double store_est_vals[BUFFER_SIZE];
        double *stored_est_val = est_position(list, list->plane_data[i].id, command, store_est_vals);
        if (distance(stored_est_val[0], stored_est_val[1]) < operating_radius && stored_est_val[4] != -1) {
            plane_counter++;
        }
    }
    printf("Currently tracking %d aircraft\n", plane_counter);
}

void print_check_separation(List *list, char command[BUFFER_SIZE]){
    double pos[3] = {0,0,0}; //initialise pos to eliminate any 'garbage' values
    int sep_id; int sep_hour; int sep_minute; //extracting ID and time, to use in calculations
    double R; //minimum separation distance
    sscanf(command, "*time:%d:%d,check_separation,%d,%lf", &sep_hour, &sep_minute, &sep_id, &R);
    //Run calculations, collect return values
    double *intersect_pos = check_separation(list, sep_id, command, R, pos);
    if (!intersect_pos[2] || (intersect_pos[0] == 0 && intersect_pos[1] == 0)){
        printf("No separation issues\n");
    }
    if(intersect_pos[0] != 0 && intersect_pos[1] != 0){
        printf("Separation issue: N:%.1f,E:%.1f\n", intersect_pos[0], intersect_pos[1]);
    }
}

int process_command(List *list, char command[BUFFER_SIZE]){
    //closing
    char *last_five = last_five_chars(command);
    if (strncmp(last_five, "close", 5) == 0) {
        printf("closing\n");
        return 1; // Return 1 to indicate that "close" was encountered.
    }

    //Estimated position
    char subcommand1[BUFFER_SIZE]; 
    // Extract 'est_pos' command (if written)
    strncpy(subcommand1, command + 12, 8);
    if (strncmp(subcommand1, "est_pos", 7) == 0) {
        print_est_position(list, command);
    }

    //Number of contacts
    char subcommand2[BUFFER_SIZE];
    // Extract 'num_contacts' command (if written)
    strcpy(subcommand2, command + 12);
    if (strncmp(subcommand2, "num_contacts", 12) == 0) {
        print_num_contacts(list, command);
    }

    //Check for separation
    char subcommand3[BUFFER_SIZE]; 
    //Extract 'check_separation' command (if written)
    strncpy(subcommand3, command + 12, 16); 
    if (strncmp(subcommand3, "check_separation", 16)==0){
        print_check_separation(list, command);
    }
    return 0; //indicate that "close" was not encountered
}

int input_command(List *list) {
    char input[BUFFER_SIZE];

    for (int i = 0;; i++) {
        //store input into 'input' array
        fgets(input, BUFFER_SIZE, stdin);

        // Remove newline character (if present)
        size_t len = strlen(input);
        if (len > 0 && input[len - 1] == '\n') {
            input[len - 1] = '\0';
        }

        //Aircraft data input
        if (strncmp(input, "#ADS-B", 6) == 0) {
            // Here, we are parsing the input and populating the ADSBPacket structure.
            if (i >= list->capacity) {
                // Check if the current index exceeds the capacity
                list->capacity *= 2;
                list->plane_data = realloc(list->plane_data, list->capacity * sizeof(ADSBPacket));
            }
            sscanf(input, "#ADS-B:%d,time:%d:%d,N:%lf,E:%lf,alt:%d,head:%lf,speed:%lf", 
                   &list->plane_data[i].id, &list->plane_data[i].hour, 
                   &list->plane_data[i].minute, &list->plane_data[i].north, 
                   &list->plane_data[i].east, &list->plane_data[i].altitude, 
                   &list->plane_data[i].heading, &list->plane_data[i].speed);

            append_data(list, list->plane_data[i]);
        }

        //Air traffic control command 
        if (strncmp(input, "*time:", 6) == 0) {
            int closing = process_command(list, input);
            if (closing){
                return 1; //indicate that "close" was encountered
            }
        }
    }
    return 0; //indicate that "close" was not encountered.
}


int main(void) {
    List my_list = init_list();
    
    int close_encountered = input_command(&my_list);

    // Free dynamically allocated memory when done
    free(my_list.plane_data);

    if (close_encountered) {
        // "close" was encountered, so exit the program.
        return 0;
    }
}









